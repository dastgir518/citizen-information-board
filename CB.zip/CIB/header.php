<html>
    <head>
        
        <?php
        require_once 'connection.php';
        require_once 'functions.php';
        session_start();
        $site_title="Search Citizen";
        ?>
        
<!--         <link type="text/css" rel="stylesheet" href="bootstrap/css/bootstrap.css">
        <link type="text/css" rel="stylesheet" href="stylesheet.css">
        <script type="text/javascript" src="bootstrap/js/bootstrap.js"></script> -->
            <link rel="stylesheet" href="bootstrap/css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="style.css">
        <title><?php echo $site_title;?></title>
        
    </head>
<div class="topbar">
 <nav class="navbar navbar-light bg-light justify-content-between">
  <a class="navbar-brand h4">Citizen Information Board of Pakistan
</a>
  <form class="form-inline">
    <?php
//welcome
if(isset($_SESSION['user_type'])){
    $type=$_SESSION['user_type'];
    $name=$_SESSION['name'];
    echo '<a class="btn btn-danger" href="logout.php">logout '.$name.'</a>';
}else{
   echo '<button type="button" class="btn btn-primary"><a href="login.php"  style="text-decoration: none; color: white;">Login</a></button>';
   echo '<button type="button" class="btn btn-primary"><a href="register.php"  style="text-decoration: none; color: white;">Register</a></button>'; 
}
?>
    
  </form>
</nav>
</div>

<div class="mynav">
 <nav class="navbar navbar-light bg-light justify-content-between">
  <ul class="navbar-nav mx-auto">
      <li class="nav-item active">
        <a href="index.php">Home  </a>
        <a href="people_search.php">Public Record </a>
        <a href="view_Criminal_Record.php">Criminal Record  </a>
        <a href="view_Court_Record.php">Court Record </a>
        <a href="view_phone_book.php">PhoneBook </a>
        <a href="family_tree.php">Family Tree  </a>
        <a href="about.php">About  </a>
        <a href="faq.php">FAQs </a>
        <span class="c"><a href="send_feedback.php">Contact Us</a></span>
      </li>
  </ul>
</nav>
</div>





    <body>
        
