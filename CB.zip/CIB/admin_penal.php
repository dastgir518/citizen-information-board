

<?php
require_once 'header.php';
confirm_user("admin");
?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="stylesheet.css">


<div class="sidenav">
  <?php
//welcome
if(isset($_SESSION['user_type'])){
    $type=$_SESSION['user_type'];
    $name=$_SESSION['name'];
    echo "<h3 class=\"text-primary\">Wellcome $name ($type)</h3>";
}
?>
<button class="dropdown-btn">Add Recordes
  <i class="fa fa-caret-down"></i>
  </button>
  <div class="dropdown-container">
    <a  href="add_person.php">+Person</a>
    <a href="add_criminal_record.php">+Criminal Record</a>
    <a href="add_Court_Record.php">+Court Record</a>
    <a href="add_phone_book.php">+Phone Book</a>
    <a href="add_family_tree.php">+Family Tree</a>
    <a href="add_family_code.php">+Family Code</a>
    <a href="add_public_record.php">+Public Record</a>
    <a href="add_faq.php">+FAQ</a>
  </div>

  <button class="dropdown-btn">Edit Recordes
  <i class="fa fa-caret-down"></i>
  </button>
  <div class="dropdown-container">
    <a  href="edit_person.php">Edit Person</a>
    <a href="edit_crime_record.php">Edit Criminal Record</a>
    <a href="edit_court_record.php">Edit Court Record</a>
    <a href="edit_phone.php">Edit Phone Book</a>
    <a href="add_family_tree.php">+Family Tree</a>
    <a href="add_family_code.php">+Family Code</a>
    <a href="add_public_record.php">+Public Record</a>
    <a href="add_faq.php">+FAQ</a>
  </div>

<a href="view_feedback.php">View Feedback</a>
</div>

<div class="main">
  
  
</div>
<script>
/* Loop through all dropdown buttons to toggle between hiding and showing its dropdown content - This allows the user to have multiple dropdowns without any conflict */
var dropdown = document.getElementsByClassName("dropdown-btn");
var i;

for (i = 0; i < dropdown.length; i++) {
  dropdown[i].addEventListener("click", function() {
  this.classList.toggle("active");
  var dropdownContent = this.nextElementSibling;
  if (dropdownContent.style.display === "block") {
  dropdownContent.style.display = "none";
  } else {
  dropdownContent.style.display = "block";
  }
  });
}
</script>
<?php
require_once 'footer.php';
?>