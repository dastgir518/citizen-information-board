<?php 
require 'header.php';
confirm_user("admin");

if (isset($_POST)) {
	// echo $_POST['id'];



    //For UPdateing Person
	
	if ($_POST['id'] == 'Update Person') {


    $name=$_POST['name'];
    $father_name=$_POST['father_name'];
    $cnic=$_POST['cnic'];
    $dob = $_POST['dob'];
    $marital_status=$_POST['marital_status'];
    $address=$_POST['address'];
    $id = $_POST['person_d'];
    $status=$_POST['status'];
echo $id;
    $query="
    UPDATE  person SET 
    	name = '$name', 
    	father_name = '$father_name', 
    	cnic = '$cnic',
        dob = '$dob',
    	marital_status = '$marital_status', 
    	address = '$address',  
    	status = '$status' 
    WHERE person_id = '$id'";
   
    $result= mysqli_query($link, $query);
    if($result){
    	alert("Record Updated");
        redirect_to("edit_person.php");
    }else {
    	alert(mysqli_error($result));
    }
   
		
}
// For Updating Crime Record


if ($_POST['id'] == 'Update crime') {
   
   $crime = $_POST['crime'];
   $details = $_POST['details'];
   $date = $_POST['date'];
   $status = $_POST['status'];
   $rid = $_POST['record_id']; 
   $query = "
   UPDATE crime_record SET
   crime = '$crime',
   details = '$details',
   date = '$date',
   status = '$status'
   WHERE crime_record_id = '$rid'
   ";
   $result = mysqli_query($link , $query);
   if ($result) {
       alert("Record Updated"); 
       redirect_to("edit_crime_record.php");
         }

} 

// For Updating Crime Record

if ($_POST['id'] == 'Update court') {
   
   $trial = $_POST['trial'];
   $details = $_POST['details'];
   $date = $_POST['date'];
   $status = $_POST['status'];
   $rid = $_POST['record_id']; 
   $query = "
   UPDATE court_record SET
   trial = '$trial',
   details = '$details',
   date = '$date',
   status = '$status'
   WHERE court_record_id = '$rid'
   ";
   $result = mysqli_query($link , $query);
   if ($result) {
       alert("Record Updated"); 
       redirect_to("edit_court_record.php");
         }

} 



//For updating phonebook


if ($_POST['id'] == 'Update phone') {
   
   $phone = $_POST['phone'];
   $type = $_POST['type'];
   $date = $_POST['date'];
   $rid = $_POST['record_id']; 
   $query = "
   UPDATE phone_book SET
   phone = '$phone',
   type = '$type',
   date = '$date'
   WHERE phone_book_id = '$rid'
   ";
   $result = mysqli_query($link , $query);
   if ($result) {
       alert("Record Updated"); 
       redirect_to("edit_phone.php");
         }

} 















}









 ?>