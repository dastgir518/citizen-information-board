<?php
require_once 'header.php';
?>
<br>
<a class="btn btn-success" href="index.php">Back</a>
<h1>Contact us</h1>
<p class="text text-capitalize text-justify" style="font-size: 24">
“Citizens Information Board of Pakistan” is website to facilitate the citizens to search and get the authentic information about other citizens of Pakistan. It will provide on hand information about anyone. The aim of this website is to reduce the chances of frauds by eliminating the fake bio data of people. System will also reduce the manual effort and cost required for verification through Govt. law departments. So, it will benefit the both public and government. 
This website offers following categories:<br><br>
For Any Help<br>
Feel Free To Contact at <br>
<a href="mailto:xyz@abc.com">xyz@abc.com</a><br>
+92 000 1234567
</p>

<?php
require_once 'footer.php';
?>