<?php
require_once 'header.php';
confirm_user("admin");
?>
<a class="btn btn-success" href="index.php">Back</a>
<br>

<table class="table table-responsive table-bordered">
    <caption class="h1 text-center text-primary">Crime Record</caption>
        <tr class="active">
            <th>Name</th>
            <th>Details</th>
            <th>Date</th>
        </tr>
<?php
//processing 
$query="select * from feedback inner join user on feedback.user_id=user.user_id";
$result= mysqli_query($link, $query);
if(mysqli_num_rows($result)){
    while($row= mysqli_fetch_array($result)){
        ?>
    <tr>
    <td><?php echo $row['name'];?></td>
    <td><?php echo $row['details'];?></td>
    <td><?php echo $row['datee'];?></td>
    </tr>
    <?php
    }
}else{
    alert(mysqli_error($link));
}
?>
        
        

<?php
require_once 'footer.php';
?>