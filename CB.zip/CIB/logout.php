<?php
//including head portion
    require_once 'header.php';
    confirm_logged_in();
?>

<?php
//loging out
    session_destroy();
    alert("You have been logged-out successfuly.");
    redirect_to("index.php");
?>

<?php
//including footer portion
    require_once 'footer.php';
?>