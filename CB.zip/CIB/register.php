<?php
require_once 'header.php';
confirm_not_logged_in();
?>

<?php
//reg process
if(isset($_POST['submit'])){
    
    $name=$_POST['name'];
    $email=$_POST['email'];
    $password=$_POST['pass'];
    $phone=$_POST['phone'];
    $city=$_POST['city'];   
    $user_type=$_POST['user_type'];
   
    $query="insert into user (name, email, password, phone, city, type) values";
    $query.="('$name', '$email', '$password', '$phone', '$city', '$user_type')";
    $result= mysqli_query($link, $query);
    if(mysqli_insert_id($link)){
        alert("You have been Registered successfuly.");
        redirect_to("index.php");
    }else{
        alert(mysqli_error($link));
    }
}
    
?>
<br>
<a class="btn btn-primary" href="index.php">Home Page</a><br>
<h1 class="text text-center">Registration</h1>
<form method="post" action="" class="form-horizontal">
    <div class="col-sm-2"></div>
    <table class="col-sm-7">
        <tr>
            <td><label>Name:</label></td>
            <td><input type="text" name="name" placeholder="Enter Name" required="" autofocus="" class="form-control"><br></td>
        </tr>
        <tr>
            <td><label>Email:</label></td>
            <td><input type="email" name="email" placeholder="Enter Email" required="" class="form-control"><br></td>
        </tr>
        <tr>
            <td><label>Password:</label></td>
            <td><input type="password" name="pass" placeholder="Enter Password" required="" class="form-control"><br></td>
        </tr>
        <tr>
            <td><label>Phone:</label></td>
            <td><input type="number" name="phone" placeholder="Enter Phone #" required="" class="form-control"><br></td>
        </tr>
        <tr>
            <td><label>City:</label></td>
            <td><input type="text" name="city" placeholder="Enter City Name" required="" class="form-control"><br></td>
        </tr>
        <tr>
            <td><label>User Type:</label> </td>
            <td>
                <select name="user_type" required="" class="form-control">
                    <option value="">Select A Type</option>
                    <option value="User">User</option>
                    <option value="Admin">Admin</option>
                </select><br>
            </td>
        </tr>         
        <tr>
            <td></td>
            <td>
                <input type="submit" name="submit" value="Proceed" class="btn btn-success">
                <input type="reset" name="reset" value="Clear" class="btn btn-warning">
                <a class="btn btn-danger" href="login.php">Already Registered</a>                        
            </td>
        </tr>                
    </table>
</form>        
    
<?php
require_once 'footer.php';
?>