<?php
require_once 'header.php';
confirm_user("admin");
?>
<style type="text/css">
    form button{
        position: absolute;
        top: 25%;
        left: 100%;
    }
    .table{
        width: 100%;
        margin-left: 10%;
    }
</style>
<a class="btn btn-success" href="index.php">Back</a>
<br>



<form method="post" action="" class="form-horizontal" enctype="multipart/form-data">
    <div class="col-sm-3"></div>
    
        <h1 class="text-primary text-center">Edit Crime Details</h1>
        <div class="row">
            <div class="col-md-3"></div>
            <div class="col-md-4"> 
            Select Person:
                <select name="person_id" required="" class="form-control">
                    <option value="">Select An Option</option>
                    <?php
                    $result= mysqli_query($link, "select * from person");
                    while($row= mysqli_fetch_array($result)){
                        ?>
                    <option value="<?php echo $row['person_id'];?>"><?php echo $row['name'];?></option>
                    <?php
                    }
                    ?>
                </select>
                <button type="submit" name="submit" class="btn btn-success" value='Proceed'>Edit</button>
                <br>
    </div>
        </div>
           
  
</form>      
  <table class="table table-responsive ">      
  <?php
if(isset($_REQUEST['submit'])){
    $person_d=$_REQUEST['person_id'];
    $query="SELECT * FROM crime_record Where person_id = $person_d";
    $result= mysqli_query($link, $query);
    if(mysqli_num_rows($result)){
         echo '   
    <thead>
        <tr class="active">
            <th>Crime</th>
            <th>Detail</th>
            <th>Date</th>         
            <th>Status</th> 
            <th></th>
        </tr>
        </thead>
        <tbody> ';
        while($row= mysqli_fetch_array($result)){
        
            echo '
            <form method="post" action="update.php" class="form-horizontal" enctype="multipart/form-data">
        <tr>
        <td><input type="text" name="crime" value="'.$row['crime'].'"  required="" autofocus="" class="form-control"></td>
        <td><input type="text" name="details" value="'.$row['details'].'"  required="" autofocus="" class="form-control"></td>
        <td><input type="date" name="date" value="'.$row['date'].'"  required="" autofocus="" class="form-control"></td>
        <td><input type="text" name="status" value="'.$row['status'].'"  required="" autofocus="" class="form-control"></td>
        <input type="hidden" value="'. $row['crime_record_id'].'" name="record_id">
        <td><input type="submit" name="id" value="Update crime" class="btn btn-success"></td>
        </tr></form>
        ';

        };

    }else{
        alert("No Record Found");
    }
}
?>
        

  </tbody></table>   

<?php
require_once 'footer.php';
?>