<?php
require_once 'header.php';
confirm_user("admin");
?>
<a class="btn btn-success" href="index.php">Back</a>
<br>

<?php
if(isset($_REQUEST['submit'])){
    $person_id=$_REQUEST['person_id'];
    $trial=$_REQUEST['trial'];
    $details=$_REQUEST['details'];
    $date=$_REQUEST['date'];
    $status=$_REQUEST['status'];
    $query="insert into court_record ";
    $query.="(person_id, trial, details, date, status)";
    $query.="values('$person_id','$trial','$details','$date','$status' )";
    $result= mysqli_query($link, $query);
    if(mysqli_insert_id($link)){
        alert("Details has been successfuly saved,");
    }else{
        alert(mysqli_error($link));
    }
}
?>

<form method="post" action="" class="form-horizontal" enctype="multipart/form-data">
    <div class="col-sm-3"></div>
    <table class="col-sm-9">
        <h1 class="text-primary">Add Court Record</h1>
        <tr>
            <td>Person:</td>
            <td>
                <select name="person_id" required="" class="form-control">
                    <option value="">Select An Option</option>
                    <?php
                    $result= mysqli_query($link, "select * from person");
                    while($row= mysqli_fetch_array($result)){
                        ?>
                    <option value="<?php echo $row['person_id'];?>"><?php echo $row['name'];?></option>
                    <?php
                    }
                    ?>
                </select>
                <br>
            </td>
        </tr>        
        <tr>
            <td>Crime:</td>
            <td><input type="text" name="trial" placeholder="Enter Trial" required="" autofocus="" class="form-control"><br></td>
        </tr>
        <tr>
            <td>Details: </td>
            <td><input type="text" name="details" placeholder="Enter Detail" required="" class="form-control"><br></td>
        </tr>
        <tr>
            <td>Date:</td>
            <td><input type="date" name="date" placeholder="Enter Date Of Birth" required="" class="form-control"><br></td>
        </tr>
        <tr>
            <td>Status:</td>
            <td><input type="text" name="status" placeholder="Enter Status" required="" class="form-control"><br></td>
        </tr>        
        <tr>
            <td></td>
            <td>
                <input type="submit" name="submit" value="Proceed" class="btn btn-success">
                <input type="reset" name="reset" value="Clear" class="btn btn-warning">                     
            </td>
        </tr>                
    </table>
</form>      
        
        

<?php
require_once 'footer.php';
?>