-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 03, 2020 at 08:47 PM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.3.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `citizens_information_board`
--
CREATE DATABASE IF NOT EXISTS `citizens_information_board` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `citizens_information_board`;

-- --------------------------------------------------------

--
-- Table structure for table `court_record`
--

CREATE TABLE `court_record` (
  `court_record_id` int(11) NOT NULL,
  `person_id` int(11) NOT NULL,
  `trial` varchar(100) NOT NULL,
  `details` text NOT NULL,
  `date` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `court_record`
--

INSERT INTO `court_record` (`court_record_id`, `person_id`, `trial`, `details`, `date`, `status`) VALUES
(1, 1, 'trail', 'det', '11111', 'cleared'),
(2, 3, 'Fighting', 'this was sample court rocrd', '2020-02-13', 'cleaned');

-- --------------------------------------------------------

--
-- Table structure for table `crime_record`
--

CREATE TABLE `crime_record` (
  `crime_record_id` int(11) NOT NULL,
  `person_id` int(11) NOT NULL,
  `crime` varchar(100) NOT NULL,
  `details` text NOT NULL,
  `date` text NOT NULL,
  `status` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `crime_record`
--

INSERT INTO `crime_record` (`crime_record_id`, `person_id`, `crime`, `details`, `date`, `status`) VALUES
(1, 1, 'crime', 'det', '111', 'status'),
(2, 3, 'Kinap ', 'this was a sample kidnap', '2020-02-07', 'cleared');

-- --------------------------------------------------------

--
-- Table structure for table `family_number`
--

CREATE TABLE `family_number` (
  `family_number_id` int(11) NOT NULL,
  `detail` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `family_number`
--

INSERT INTO `family_number` (`family_number_id`, `detail`) VALUES
(1000, 'Guru'),
(21043, 'Gondal');

-- --------------------------------------------------------

--
-- Table structure for table `family_tree`
--

CREATE TABLE `family_tree` (
  `family_tree_id` int(11) NOT NULL,
  `person_id` int(11) NOT NULL,
  `family_number` int(11) NOT NULL,
  `relation` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `family_tree`
--

INSERT INTO `family_tree` (`family_tree_id`, `person_id`, `family_number`, `relation`) VALUES
(1, 1, 1000, 'Father'),
(2, 2, 1000, 'Son'),
(3, 3, 1000, 'Brother');

-- --------------------------------------------------------

--
-- Table structure for table `faq`
--

CREATE TABLE `faq` (
  `faq_id` int(11) NOT NULL,
  `question` text NOT NULL,
  `answer` text NOT NULL,
  `date` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `faq`
--

INSERT INTO `faq` (`faq_id`, `question`, `answer`, `date`) VALUES
(1, 'What is Citizen Information Board?', '“Citizens Information Board of Pakistan” is website to facilitate the citizens to search and get the authentic information about other citizens of Pakistan', '2012-12-12'),
(2, 'How search a personal record ', 'The registered/non-registered users can search the data of citizens by Name, Father/Guardian Name, CNIC and Date of Birth using search filed.', '0000-00-00'),
(3, 'How search a personal record ', 'The registered/non-registered users can search the data of citizens by Name, Father/Guardian Name, CNIC and Date of Birth using search filed.', '2020-02-04');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `feedback_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `details` text NOT NULL,
  `date` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`feedback_id`, `user_id`, `details`, `date`) VALUES
(1, 1, 'feedback', '111');

-- --------------------------------------------------------

--
-- Table structure for table `message`
--

CREATE TABLE `message` (
  `message_id` int(11) NOT NULL,
  `sender_id` int(11) NOT NULL,
  `subject` text NOT NULL,
  `message` text NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `message`
--

INSERT INTO `message` (`message_id`, `sender_id`, `subject`, `message`, `date`) VALUES
(1, 1, 'Feedback', 'this is feed back', '2020-02-03'),
(2, 1, 'Feedback', 'sadfasdfasdf', '2020-02-03'),
(3, 1, 'Feedback', 'sadfasdfasdf', '2020-02-03');

-- --------------------------------------------------------

--
-- Table structure for table `person`
--

CREATE TABLE `person` (
  `person_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `father_name` varchar(33) NOT NULL,
  `cnic` int(11) NOT NULL,
  `dob` varchar(33) NOT NULL,
  `marital_status` varchar(33) NOT NULL,
  `address` text NOT NULL,
  `picture` text NOT NULL,
  `status` varchar(33) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `person`
--

INSERT INTO `person` (`person_id`, `name`, `father_name`, `cnic`, `dob`, `marital_status`, `address`, `picture`, `status`) VALUES
(1, 'person', 'f_name', 90909090, '1111-22-22', 'Married', 'address', 'file not', 'Alive'),
(2, 'nnnnn', 'f_namedsdf', 98709870, '987098', 'single', 'sasdfasd', 'sdf', 'sf'),
(3, 'Aslam', 'Saleem', 2147483647, '2020-02-03', 'Single', 'sgd', 'images/Capture.PNG', 'sfdasdf');

-- --------------------------------------------------------

--
-- Table structure for table `phone_book`
--

CREATE TABLE `phone_book` (
  `phone_book_id` int(11) NOT NULL,
  `person_id` int(11) NOT NULL,
  `phone` int(11) NOT NULL,
  `home` int(11) NOT NULL,
  `work` int(11) NOT NULL,
  `date` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `phone_book`
--

INSERT INTO `phone_book` (`phone_book_id`, `person_id`, `phone`, `home`, `work`, `date`) VALUES
(1, 1, 111, 222, 333, '0000-00-00'),
(2, 3, 1111111111, 22222222, 333333333, '2020-02-04');

-- --------------------------------------------------------

--
-- Table structure for table `public_record`
--

CREATE TABLE `public_record` (
  `public_record_id` int(11) NOT NULL,
  `person_id` int(11) NOT NULL,
  `head` varchar(100) NOT NULL,
  `details` text NOT NULL,
  `status` varchar(100) NOT NULL,
  `date` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `public_record`
--

INSERT INTO `public_record` (`public_record_id`, `person_id`, `head`, `details`, `status`, `date`) VALUES
(1, 1, 'head', 'publ record', '', '1212'),
(2, 3, 'Good Social Worker', 'he is a good social worker', 'alive', '2020-02-07');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL,
  `name` varchar(33) NOT NULL,
  `email` varchar(33) NOT NULL,
  `password` varchar(33) NOT NULL,
  `phone` int(33) NOT NULL,
  `city` varchar(33) NOT NULL,
  `type` varchar(33) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `name`, `email`, `password`, `phone`, `city`, `type`) VALUES
(1, 'Safdar', 'u@u.com', 'uuuu', 888, 'cuity', 'User'),
(2, 'Malik', 'a@a.com', 'aaaa', 9090, 'city', 'Admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `court_record`
--
ALTER TABLE `court_record`
  ADD PRIMARY KEY (`court_record_id`),
  ADD KEY `person_id` (`person_id`);

--
-- Indexes for table `crime_record`
--
ALTER TABLE `crime_record`
  ADD PRIMARY KEY (`crime_record_id`),
  ADD KEY `person_id` (`person_id`);

--
-- Indexes for table `family_number`
--
ALTER TABLE `family_number`
  ADD PRIMARY KEY (`family_number_id`);

--
-- Indexes for table `family_tree`
--
ALTER TABLE `family_tree`
  ADD PRIMARY KEY (`family_tree_id`),
  ADD KEY `family_number` (`family_number`),
  ADD KEY `person_id` (`person_id`);

--
-- Indexes for table `faq`
--
ALTER TABLE `faq`
  ADD PRIMARY KEY (`faq_id`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`feedback_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `message`
--
ALTER TABLE `message`
  ADD PRIMARY KEY (`message_id`);

--
-- Indexes for table `person`
--
ALTER TABLE `person`
  ADD PRIMARY KEY (`person_id`);

--
-- Indexes for table `phone_book`
--
ALTER TABLE `phone_book`
  ADD PRIMARY KEY (`phone_book_id`),
  ADD KEY `person_id` (`person_id`);

--
-- Indexes for table `public_record`
--
ALTER TABLE `public_record`
  ADD PRIMARY KEY (`public_record_id`),
  ADD KEY `person_id` (`person_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `court_record`
--
ALTER TABLE `court_record`
  MODIFY `court_record_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `crime_record`
--
ALTER TABLE `crime_record`
  MODIFY `crime_record_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `family_number`
--
ALTER TABLE `family_number`
  MODIFY `family_number_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21044;

--
-- AUTO_INCREMENT for table `family_tree`
--
ALTER TABLE `family_tree`
  MODIFY `family_tree_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `faq`
--
ALTER TABLE `faq`
  MODIFY `faq_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `feedback_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `message`
--
ALTER TABLE `message`
  MODIFY `message_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `person`
--
ALTER TABLE `person`
  MODIFY `person_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `phone_book`
--
ALTER TABLE `phone_book`
  MODIFY `phone_book_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `public_record`
--
ALTER TABLE `public_record`
  MODIFY `public_record_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `court_record`
--
ALTER TABLE `court_record`
  ADD CONSTRAINT `court_record_ibfk_1` FOREIGN KEY (`person_id`) REFERENCES `person` (`person_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `crime_record`
--
ALTER TABLE `crime_record`
  ADD CONSTRAINT `crime_record_ibfk_1` FOREIGN KEY (`person_id`) REFERENCES `person` (`person_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `family_tree`
--
ALTER TABLE `family_tree`
  ADD CONSTRAINT `family_tree_ibfk_1` FOREIGN KEY (`person_id`) REFERENCES `person` (`person_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `family_tree_ibfk_2` FOREIGN KEY (`family_number`) REFERENCES `family_number` (`family_number_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `feedback`
--
ALTER TABLE `feedback`
  ADD CONSTRAINT `feedback_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `phone_book`
--
ALTER TABLE `phone_book`
  ADD CONSTRAINT `phone_book_ibfk_1` FOREIGN KEY (`person_id`) REFERENCES `person` (`person_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `public_record`
--
ALTER TABLE `public_record`
  ADD CONSTRAINT `public_record_ibfk_1` FOREIGN KEY (`person_id`) REFERENCES `person` (`person_id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
