<?php
require_once 'header.php';
confirm_user("admin");
?>
<a class="btn btn-success" href="index.php">Back</a>
<br>

<?php
if(isset($_REQUEST['submit'])){
    $name=$_REQUEST['name'];
    $father_name=$_REQUEST['father_name'];
    $cnic=$_REQUEST['cnic'];
    $dob=$_REQUEST['dob'];
    $marital_status=$_REQUEST['marital_status'];
    $address=$_REQUEST['address'];
    //picture
    if($_FILES['picture']['error']==0){
        $pic_name=$_FILES['picture']['name'];
        $pic_name="images/".$pic_name;
        $temp_name=$_FILES['picture']['tmp_name'];
        move_uploaded_file($temp_name, $pic_name);
    }else{
        alert("picture uploading err");
    }
    $status=$_REQUEST['status'];
    $query="insert into person ";
    $query.="(name, father_name, cnic, dob, marital_status, address, picture, status)";
    $query.="values('$name','$father_name','$cnic','$dob','$marital_status','$address','$pic_name','$status' )";
    $result= mysqli_query($link, $query);
    if(mysqli_insert_id($link)){
        alert("Person details has been successfuly saved,");
    }else{
        alert(mysqli_error($link));
    }
}
?>

<form method="post" action="" class="form-horizontal" enctype="multipart/form-data">
    <div class="col-sm-3"></div>
    <table class="col-sm-9">
        <h1 class=" text-primary">Add A Person</h1>
        <tr>
            <td>Name:</td>
            <td><input type="text" name="name" placeholder="Enter Name" required="" autofocus="" class="form-control"><br></td>
        </tr>
        <tr>
            <td>Father Name: </td>
            <td><input type="text" name="father_name" placeholder="Enter Father Name" required="" class="form-control"><br></td>
        </tr>
        <tr>
            <td>CNIC:</td>
            <td><input type="text" name="cnic" placeholder="Enter CNIC" required="" class="form-control"><br></td>
        </tr>
        <tr>
            <td>DOB:</td>
            <td><input type="date" name="dob" placeholder="Enter Date Of Birth" required="" class="form-control"><br></td>
        </tr>
        <tr>
            <td>Marital Status:</td>
            <td>
                <select  name="marital_status" required="" class="form-control">
                    <option value="">Select An Option</option>
                    <option value="Single">Single</option>
                    <option value="Married">Married</option>
                </select>
                    <br></td>
        </tr>
        <tr>
            <td>Address:</td>
            <td><input type="text" name="address" placeholder="Enter Addres" required="" class="form-control"><br></td>
        </tr>
        <tr>
            <td>Picture:</td>
            <td><input type="file" name="picture" required="" class="form-control"><br></td>
        </tr>
        <tr>
            <td>Status:</td>
            <td><input type="text" name="status" placeholder="Enter Status" required="" class="form-control"><br></td>
        </tr>        
        <tr>
            <td></td>
            <td>
                <input type="submit" name="submit" value="Proceed" class="btn btn-success">
                <input type="reset" name="reset" value="Clear" class="btn btn-warning">                     
            </td>
        </tr>                
    </table>
</form>      
        
        

<?php
require_once 'footer.php';
?>