<?php
//including head portion
    require_once 'header.php';
    confirm_user("user");
?>
<a class="btn btn-success" href="index.php">Back</a>
<br>
<?php
//adding a news
if(isset($_REQUEST["submit"])){
    
    $message=$_REQUEST["message"];
    $sender_id=$_SESSION['user_id'];
    $date= date("Y-m-d");
    $query="insert into feedback (user_id, details, datee) values";
    $query.="('$sender_id','$message', '$date')";
    $result = mysqli_query($link, $query);
    if(mysqli_insert_id($link)){
        alert("Feedback has been sent successfuly.");
        redirect_to("index.php");
    }else{
        alert(mysqli_error($link));
    }
}
?>

<form name="mail" action="" method="post" class="form-horizontal">   

     <div class="form-group">
         <label for="message" class="col-sm-3 control-label">Feedback</label>
         <div class="col-sm-6">
             <textarea name="message" id="message" style="height: 200px" required="" placeholder="Your Feedback Here.. " class="form-control"></textarea>
         </div>
     </div>   

      <div class="form-group">
         <div class="col-sm-3">
         </div>
         <div class="col-sm-6">                                
            <button type="submit" name="submit" class="btn btn-success btn-block">Submit</button>                   
            <button type="reset" name="reset" class=" btn btn-warning btn-block">Clear</button>   
            <a href="index.php" class="btn btn-danger btn-block">Cancel</a>
         </div>
     </div> 

 </form>             


<?php
//including footer portion
    require_once 'footer.php';
?>