<?php
$acf_kicker;
 if (have_rows('hero_header') ) : ?>
    <?php while( have_rows('hero_header') ) : the_row(); ?>
        <?php
        $GLOBALS['acf_kicker'] = get_sub_field('kicker'); // grab kicker field if it exists
        $acf_headline = get_sub_field('headline'); // grab headline field if it exists
        ?>
    <?php endwhile; ?>
<?php endif; //  end have_rows('hero_header' ?>

<?php 
$category = get_the_category(); $kicker_alt = $category[0]->name; // get category name
$kicker = $acf_kicker ?: $kicker_alt; // if acf_kicker exists, else get the category
$headline = $acf_headline ?: get_the_title();
 // if acf_headline exists, else get the post title
?>

<?php 
$teaser_image_url = get_the_post_thumbnail_url($post->ID, 'thumbnail') ? : "https://i0.wp.com/www.ladsholidayguide.com/wp-content/uploads/g-logo.png?w=360h=240&ssl=1"
?>

<a href="<?php echo esc_url(get_permalink()); ?>" title="<?php echo esc_attr ( get_the_title ()); ?>" class="teaser bg-white">
    <figure class="z-index-1 ratio" data-ratio="3:2">
        <img src="data:image/png;base64,R0lGODlhAQABAAD/ACwAAAAAAQABAAACADs="
        alt="<?php echo esc_attr(get_the_title()); ?>"
        data-src="<?php echo esc_attr($teaser_image_url); ?>"
        loading="lazy" class="lazyload">
    </figure>
    <header class="header">
        <strong class="kicker"><?php echo $kicker; ?></strong>
        <h4 class="headline"><?php echo $headline; ?></h4>
    </header>
</a>

<?php if( have_rows('hero_images') ) : ?>
<?php while( have_rows('hero_images') ): the_row(); ?>
<?php // grab ACF image if it exists...
$acf_hero_image_url = wp_get_attachment_image_src(get_sub_field('hero_image_portrait'), '')[0]; 
?>
<?php endwhile; ?>
<?php endif; ?>

<?php 
// check if it exists, if not, grab the featured image or fallback image
$hero_image_url = $acf_hero_image_url ?: get_the_post_thumbnail_url($post->ID, '') ?: "data:image/png;base64,R0lGODlhAQABAAD/ACwAAAAAAQABAAACADs=";
// use jetpack to resize images for screensizes
$hero_smartphone = Jetpack_PostImages::fit_image_url ($hero_image_url, 360, 720);
$hero_tablet = Jetpack_PostImages::fit_image_url ($hero_image_url, 768, 1024);
$hero_desktop = Jetpack_PostImages::fit_image_url ($hero_image_url, 1366, 768);
$hero_desktop_plus = Jetpack_PostImages::fit_image_url ($hero_image_url, 1920, 1080);
?>