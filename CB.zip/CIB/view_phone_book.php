<?php
require_once 'header.php';
?>

<div class="container">
  <div class="h2 text-center heading"><p>Search The Citizen</p></div>
  <p class="text-center p1">You can search the phone record of peoples in this search 
    type your keyword to search information about anyone
  </p>




<div class="searchbox">
<form action="" method="post">
<div class="input-group md-form form-sm form-2 pl-0">
  <input class="form-control my-0 py-1 red-border" type="text" placeholder="Enter Name/ Father Name/ CNIC or DOB " autofocus="" required=""  name="search" aria-label="Search">
  <div class="input-group-append">
    <input type="submit" name="submit_search" value="Search" class="btn btn-primary">
  </div>
</div>
</form>
</div>
</div>




<div class="container">
  <div class="h2 text-center results"><p>Phone Data</p></div>
</div>




<table class="table table-responsive ">
    <thead>
        <tr class="active">
            <th>Name</th>
            <th>Phone</th>
            <th>type</th>
            <th>Picture</th>           
            <th>Status</th> 
        </tr>
        </thead>
    <tbody>
<?php
//processing search
if(isset($_POST['submit_search'])){
    $search=$_POST['search'];
    $query="select * from person inner join phone_book on person.person_id=phone_book.person_id where name='$search' or father_name='$search' or cnic='$search' or dob='$search' ";
    $result= mysqli_query($link, $query);
    if(mysqli_num_rows($result)){
        while($row= mysqli_fetch_array($result)){
            ?>
        <tr>
        <td><?php echo $row['name'];?></td>
        <td><?php echo $row['phone'];?></td>
        <td><?php echo $row['type'];?></td>
        <td><a target="_blank" href="<?php echo $row['picture'];?>" class="btn btn-info">View Image</a></td>
        <td><?php echo $row['status'];?></td>
        </tr>
        <?php
        }
    }else{
        alert("No Record Found");
    }
}
?>
        
  </tbody>
  </table>      

<?php
require_once 'footer.php';
?>