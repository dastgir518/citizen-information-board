<?php
require_once 'header.php';
?>
<br>
<a class="btn btn-success" href="index.php">Back</a>
<h1>FAQ</h1>

<?php
//faq displaying
    $query="select * from faq";
    $result= mysqli_query($link, $query);
    if(mysqli_num_rows($result)){
        while($row= mysqli_fetch_array($result)){
            ?>
<div class="well col-sm-12">
    <b><?php echo $row['question'];?></b><br>
    <?php echo $row['answer']; ?>
</div>
<?php

    }
}
?>
              
<br>
<?php
require_once 'footer.php';
?>