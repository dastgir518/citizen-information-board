<?php
require_once 'header.php';
index_func();
?>
<style type="text/css">
	h1{
		color: white;
	
	}
	.back{
		background-image: url('back.jpg');
		background-size: 100%;
		height: 400px;

	}
</style>
<!-- <div class="container">
	
	<div class="back"> 
	 
	<h1 class="text-center">Welcome To Citizen Information Board of Pakistan</h1>

	</div>
</div> 

<div class="container">
       <div class="row">
           <div class="col-md-6">
              <h4><strong>Here is some thing about bootstrap</strong></h4>
              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Enim rem doloremque omnis nobis delectus maiores, exercitationem, eius ullam, esse atque beatae at. Facere praesentium qui pariatur dicta dolor, labore. Cupiditate. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Pariatur nulla nam explicabo laborum harum ut, veritatis aspernatur, ratione cupiditate eligendi dolorem enim, sequi odit magni neque non doloremque, laboriosam. Aperiam.</p> 
           </div>
           <div class="col-md-6">
              <img src="bootstrap2.jpg" alt="bootstrapimg" class="img-fluid"> 
           </div>
       </div>
   </div>

   <div class="container">
       <div class="row">
           <div class="col-12 col-sm-6 col-md-3 col-lg-3">
               <h4>Build with sass</h4>
               <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Debitis ex quod animi placeat rem recusandae odio, aliquam deleniti! Eos quo vero quam, obcaecati laborum! Sed, suscipit, rerum! Doloribus, quia, excepturi!</p>
           </div>
           <div class="col-12 col-sm-6 col-md-3 col-lg-3">
           <img src="sass.png" alt="sass" class="img-fluid">
           </div>
           <div class="col-12 col-sm-6 col-md-3 col-lg-3">
               <h4>And Less</h4>
               <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Debitis ex quod animi placeat rem recusandae odio, aliquam deleniti! Eos quo vero quam, obcaecati laborum! Sed, suscipit, rerum! Doloribus, quia, excepturi!</p>
           </div>
           <div class="col-12 col-sm-6 col-md-3 col-lg-3">
           <img src="less.png" alt="sass" class="img-fluid">
           </div>
       </div>
   </div> -->


 <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
  <div class="carousel-inner">
    
    <div class="carousel-item active">
      <div class="carousel-caption">
          <h1 class="display-4 font-weight-bold">Welcome To Citizen Information Board Of Pakistan</h1>
      </div>
      <img class="d-block w-100 h-50" src="f-img.jpg" alt="Second slide">
    </div>
</div>
  
  
       <!-------------------Slider End-------------------->

   <!-------------------site body-------------------->
   <div class="container text-center">
       <br><br><br>
   </div>
   
   <div class="container">
       <div class="row">
           <div class="col-md-6">
              <h4><strong>Some things about Citizen Information Board</strong></h4>
              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Enim rem doloremque omnis nobis delectus maiores, exercitationem, eius ullam, esse atque beatae at. Facere praesentium qui pariatur dicta dolor, labore. Cupiditate. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Pariatur nulla nam explicabo laborum harum ut, veritatis aspernatur, ratione cupiditate eligendi dolorem enim, sequi odit magni neque non doloremque, laboriosam. Aperiam.</p> 
              <button class="btn btn-success"><a href="#">Start Search</a></button>
           </div>
           <div class="col-md-6">
              <img src="back.jpg" alt="bootstrapimg" class="img-fluid"> 
           </div>
       </div>
   </div><br><br><br>
   <div class="container">
       <div class="row">
           <div class="col-12 col-sm-6 col-md-3 col-lg-3">
               <h4>Our Goal</h4>
               <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Debitis ex quod animi placeat rem recusandae odio, aliquam deleniti! Eos quo vero quam, obcaecati laborum! Sed, suscipit, rerum! Doloribus, quia, excepturi!</p>
           </div>
           <div class="col-12 col-sm-6 col-md-3 col-lg-3">
           <img src="logo.png" alt="sass" class="img-fluid">
           </div>
           <div class="col-12 col-sm-6 col-md-3 col-lg-3">
               <h4>Data Protection</h4>
               <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Debitis ex quod animi placeat rem recusandae odio, aliquam deleniti! Eos quo vero quam, obcaecati laborum! Sed, suscipit, rerum! Doloribus, quia, excepturi!</p>
           </div>
           <div class="col-12 col-sm-6 col-md-3 col-lg-3">
           <img src="protect.png" alt="sass" class="img-fluid">
           </div>
       </div>
   </div>
   
   <div id="accordion" class="text-center">
            <div class="card">
            <div class="card-header" id="headingTwo">
              <h5 class="mb-0">
                <a href="hidden" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                  Care to learn more about bootstrap
                </a>
              </h5>
            </div>
            <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordion">
              <div class="card-body">
                Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
              </div>
            </div>
          </div>
        </div><br><br>

<?php
require_once 'footer.php';
?>