<?php
require_once 'header.php';
confirm_user("admin");
?>
<a class="btn btn-success" href="index.php">Back</a>
<br>

<?php
if(isset($_REQUEST['submit'])){
    $code=$_REQUEST['code'];
    $cast=$_REQUEST['cast'];
    $query="insert into family_number ";
    $query.="(family_number_id, detail)";
    $query.="values('$code','$cast' )";
    $result= mysqli_query($link, $query);
    if(mysqli_insert_id($link)){
        alert("Details has been successfuly saved,");
    }else{
        alert(mysqli_error($link));
    }
}
?>

<form method="post" action="" class="form-horizontal" enctype="multipart/form-data">
    <div class="col-sm-3"></div>
    <table class="col-sm-9">
        <h1 class="text-primary">Add Family Code</h1>
        
        <tr>
            <td>Family Code:</td>
            <td><input type="text" name="code" placeholder="Enter Family code" required="" autofocus="" class="form-control"><br></td>
        </tr>
        <tr>
            <td>Cast: </td>
            <td><input type="text" name="cast" placeholder="Enter Cast" required="" class="form-control"><br></td>
        </tr>
            <td></td>
            <td>
                <input type="submit" name="submit" value="Proceed" class="btn btn-success">
                <input type="reset" name="reset" value="Clear" class="btn btn-warning">                     
            </td>
        </tr>                
    </table>
</form>      
        
        

<?php
require_once 'footer.php';
?>