<?php
require_once 'header.php';
confirm_user("user");
?>
<h1 class="text-center"><?php echo $site_title; ?></h1>
<?php
//welcome
if(isset($_SESSION['user_type'])){
    $type=$_SESSION['user_type'];
    $name=$_SESSION['name'];
    echo "<h3 class=\"text-primary\">Wellcome $name ($type)</h3>";
}
?>

<br>

<a class="btn btn-info" href="send_feedback.php">Send Feedback</a>
<a class="btn btn-danger" href="logout.php">logout <?php echo $name;?></a>
<br><br><br><br><br>

<pre style="font-size: 24">
This website offers following categories:
•	People Search
•	Criminal Record
•	Court Record
•	Phone Book
•	Family Tree
•	Public Record
•	About 
•	Contact
•	FAQ
</pre>

<?php
require_once 'footer.php';
?>