<?php
require_once 'header.php';
confirm_user("admin");
?>
<style type="text/css">
    form button{
        position: absolute;
        top: 25%;
        left: 100%;
    }
</style>
<a class="btn btn-success" href="index.php">Back</a>
<br>



<form method="post" action="" class="form-horizontal" enctype="multipart/form-data">
    <div class="col-sm-3"></div>
    
        <h1 class="text-primary text-center">Edit Person</h1>
        <div class="row">
            <div class="col-md-3"></div>
            <div class="col-md-4"> 
            Person:
                <select name="person_id" required="" class="form-control">
                    <option value="">Select An Option</option>
                    <?php
                    $result= mysqli_query($link, "select * from person");
                    while($row= mysqli_fetch_array($result)){
                        ?>
                    <option value="<?php echo $row['person_id'];?>"><?php echo $row['name'];?></option>
                    <?php
                    }
                    ?>
                </select>
                <button type="submit" name="submit" class="btn btn-success" value='Proceed'>Edit</button>
                <br>
    </div>
        </div>
           
  
</form>      
        
  <?php
if(isset($_REQUEST['submit'])){
    $person_d=$_REQUEST['person_id'];
    $query="SELECT * FROM PERSON Where person_id = $person_d";
    $result= mysqli_query($link, $query);
    if(mysqli_num_rows($result)){
        while($row= mysqli_fetch_array($result)){
             echo '
             <form method="post" action="update.php" class="form-horizontal" enctype="multipart/form-data">
<div class="row">
    <div class="col-md-3"></div>
        <div class="col-md-6">
            Name:
            <input type="text" name="name" value="'.$row['name'].'" placeholder="Enter Name" required="" autofocus="" class="form-control"><br>
            Father Name:
            <input type="text" name="father_name" value="'.$row['father_name'].'" placeholder="Enter Father Name" required="" class="form-control"><br>
            CNIC:
            <input type="text" name="cnic" value="'.$row['cnic'].'" placeholder="Enter CNIC" required="" class="form-control"><br>
             DOB:
            <td><input type="date" name="dob" value="'.$row['dob'].'" placeholder="Enter Date Of Birth" required="" class="form-control"><br>

            Marital Status:
                <select  name="marital_status" required="" class="form-control">
                    <option value="">Select An Option</option>
                    <option '.(($row['marital_status']=='Single')?'Selected':'').' value="Single">Single</option>
                    <option '.(($row['marital_status']=='Married')?'Selected':'').'  value="Married">Married</option>
                </select>
                    <br>
            Address:
            <input type="text" value="'.$row['address'].'" name="address" placeholder="Enter Addres" required="" class="form-control"><br>
            
        
            Status:
            <input type="text" value="'.$row['status'].'" name="status" placeholder="Enter Status" required="" class="form-control"><br>
                <input type="hidden" value="'.$person_d.'" name="person_d">
                <input type="submit" name="id" value="Update Person" class="btn btn-success">
                <input type="reset" name="reset" value="Clear" class="btn btn-warning">                     
            </div>
    </div>
</form>';
        }
    }
}
?>      

<?php
require_once 'footer.php';
?>