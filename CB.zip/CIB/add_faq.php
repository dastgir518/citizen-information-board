<?php
require_once 'header.php';
confirm_user("admin");
?>
<a class="btn btn-success" href="index.php">Back</a>
<br>

<?php
if(isset($_REQUEST['submit'])){
    $question=$_REQUEST['question'];
    $answer=$_REQUEST['answer'];
    $query="insert into faq ";
    $query.="(question, answer)";
    $query.="values('$question','$answer' )";
    $result= mysqli_query($link, $query);
    if(mysqli_insert_id($link)){
        alert("Details has been successfuly saved,");
    }else{
        alert(mysqli_error($link));
    }
}
?>

<form method="post" action="" class="form-horizontal" enctype="multipart/form-data">
    <div class="col-sm-3"></div>
    <table class="col-sm-9">
        <h1 class="text-primary">Add FAQ</h1>
        
        <tr>
            <td>Question:</td>
            <td><input type="text" name="question" placeholder="Enter Question" required="" autofocus="" class="form-control"><br></td>
        </tr>
        <tr>
            <td>Answer: </td>
            <td><input type="text" name="answer" placeholder="Enter Answer" required="" class="form-control"><br></td>
        </tr>
            <td></td>
            <td>
                <input type="submit" name="submit" value="Proceed" class="btn btn-success">
                <input type="reset" name="reset" value="Clear" class="btn btn-warning">                     
            </td>
        </tr>                
    </table>
</form>      
        
        

<?php
require_once 'footer.php';
?>