<?php
mysqli_close($link);
?>








<!-- Footer -->
<footer class="page-footer font-small foot pt-4">

  <!-- Footer Links -->
  <div class="container-fluid text-center text-md-left">

    <!-- Grid row -->
    <div class="row">

      <!-- Grid column -->
      <div class="col-md-6 mt-md-0 mt-3">

        <!-- Content -->
        <h5 class="text-uppercase">Footer Content</h5>
        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
        tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
        quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
        consequat. Duis aute irure dolor in reprehenderit in .</p>

      </div>
      <!-- Grid column -->

      <hr class="clearfix w-100 d-md-none pb-3">

      <!-- Grid column -->
      <div class="col-md-2 mb-md-0 mb-3">

        <!-- Links -->
        <h5 class="text-uppercase">Important Links</h5>

        <ul class="list-unstyled">
          <li>
            <a href="#!">Link 1</a>
            <a href="#!">Link 1</a>

          </li>
          <li>
            <a href="#!">Link 2</a>
            <a href="#!">Link 2</a>

          </li>
          <li>
            <a href="#!">Link 3</a>
            <a href="#!">Link 3</a>

          </li>
     
        </ul>


      </div>
      <!-- Grid column -->

      <!-- Grid column -->
      <div class="col-md-2 mb-md-0 mb-3">

        <!-- Links -->
        <h5 class="text-uppercase">Contact</h5>

        <li>Admin@admin.com</li>
        <li>Phone : 040590494</li>

      </div>
      <!-- Grid column -->

    </div>
    <!-- Grid row -->

  </div>
  <!-- Footer Links -->

  <!-- Copyright -->
  <div class="footer-copyright text-center py-2" style="background-color: #0065BE">© 2020 Copyright:
    <a href="https://mdbootstrap.com/"> MDBootstrap.com</a>
  </div>
  <!-- Copyright -->

</footer>
<!-- Footer -->















      <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" ></script>      
    </body>












</html>