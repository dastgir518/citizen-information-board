<?php
require_once 'header.php';
confirm_user("admin");
?>

<?php
//welcome
if(isset($_SESSION['user_type'])){
    $type=$_SESSION['user_type'];
    $name=$_SESSION['name'];
    echo "<h3 class=\"text-primary\">Wellcome $name ($type)</h3>";
}
?>

<br>
<a class="btn btn-primary" href="add_person.php">+Person</a>
<a class="btn btn-primary" href="add_criminal_record.php">+Criminal Record</a>
<a class="btn btn-primary" href="add_Court_Record.php">+Court Record</a>
<a class="btn btn-primary" href="add_phone_book.php">+Phone Book</a>
<a class="btn btn-primary" href="add_family_tree.php">+Family Tree</a>
<a class="btn btn-primary" href="add_family_code.php">+Family Code</a>
<a class="btn btn-primary" href="add_public_record.php">+Public Record</a>
<a class="btn btn-primary" href="add_faq.php">+FAQ</a>
<a class="btn btn-info" href="view_feedback.php">View Feedback</a>
<a style="float: right" class="btn btn-danger" href="logout.php">logout <?php echo $name;?></a>
<br><br><br><br><br>

<pre style="font-size: 24">
This website offers following categories:
• People Search
• Criminal Record
• Court Record
• Phone Book
• Family Tree
• Public Record
• About 
• Contact
• FAQ
</pre>

<?php
require_once 'footer.php';
?>



