<?php
require_once 'header.php';
?>
<br>
<a class="btn btn-success" href="index.php">Back</a>
<h1>About Us</h1>
<p class="text text-capitalize text-justify" style="font-size: 24">
“Citizens Information Board of Pakistan” is website to facilitate the citizens to search and get the authentic information about other citizens of Pakistan. It will provide on hand information about anyone. The aim of this website is to reduce the chances of frauds by eliminating the fake bio data of people. System will also reduce the manual effort and cost required for verification through Govt. law departments. So, it will benefit the both public and government. 
This website offers following categories:
•	People Search
•	Criminal Record
•	Court Record
•	Phone Book
•	Family Tree
•	Public Record
•	About 
•	Contact
•	FAQ
Scenario:
Whenever a user will visit your website, there should be a home page, which will include the services that you are providing with a menu of categories. The registered/non-registered users can search the data of citizens by Name, Father/Guardian Name, CNIC and Date of Birth. System can show any history of the citizens like Bio Data, marital status, criminal history and family tree, etc.
 The registered user will login here and will be moving towards the search method. After that the user can give feedback and then move towards sign out.

    
</p>

<?php
require_once 'footer.php';
?>