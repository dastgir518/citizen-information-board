<?php
require_once 'header.php';
confirm_not_logged_in();
?>

<?php
//login process
if(isset($_POST['submit'])){
    $email=$_POST['email'];
    $password=$_POST['pass'];
   
    //user login
    $query="select * from user where email='$email' and password='$password' ";
    $result= mysqli_query($link, $query);
    if(mysqli_num_rows($result)){
        $row= mysqli_fetch_array($result);
        //session for login
        $_SESSION['user_id']=$row['user_id'];
        $_SESSION['user_type']=$row['type'];
        $_SESSION['email']=$row['email']; 
        $_SESSION['name']=$row['name']; 
        alert("You have been logged-in successfuly.");
        //redirecting
        $path=$_SESSION['user_type']."_penal.php";
        redirect_to($path);      
        }else{
            alert("email/ password not correct.");
        }       
}

?>
<br>
<a class="btn btn-primary" href="index.php">Home Page</a><br>
<h1 class="text text-center">Login</h1>
<form method="post" action="" class="form-horizontal">
    <div class="col-sm-2"></div>
    <table class="col-sm-7">
        <tr>
            <td>Email ID:</td>
            <td><input type="email" name="email" placeholder="Enter Email ID" required="" autofocus="" class="form-control"><br></td>
        </tr>
        <tr>
            <td>Password:</td>
            <td><input type="password" name="pass" placeholder="Enter Password" required="" class="form-control"><br></td>
        </tr>
        <tr>
            <td></td>
            <td>
                <input type="submit" name="submit" value="Proceed" class="btn btn-success">
                <input type="reset" name="reset" value="Clear" class="btn btn-warning">
                <a class="btn btn-danger" href="register.php">New User</a>                        
            </td>
        </tr>                
    </table>
</form>        
    
<?php
require_once 'footer.php';
?>