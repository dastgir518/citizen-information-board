<?php
require_once 'header.php';
?>
<h1 class="text-center"><?php echo $site_title; ?></h1>
<a class="btn btn-success" href="index.php">Back</a>
<br>

<div class="col-sm-12">
    <form action="" method="post">
        <div class="col-sm-3"></div>
        <div class="col-sm-6">
            <input type="search" name="search" placeholder="Enter Name/ Father Name/ CNIC or DOB " autofocus="" required="" class="form-control"> 
        </div>
        <div class="col-sm-3">
            <input type="submit" name="submit_search" value="Search" class="btn btn-primary">
        </div><br>
    </form>    
</div>

<table class="table table-responsive table-bordered">
    <caption class="h1 text-center text-primary">Public Record</caption>
        <tr class="active">
            <th>Name</th>
            <th>Father Name</th>
            <th>Head</th>
            <th>Detail</th>
            <th>Picture</th>           
            <th>Status</th> 
        </tr>
<?php
//processing search
if(isset($_POST['submit_search'])){
    $search=$_POST['search'];
    $query="select * from person inner join public_record on person.person_id=public_record.person_id where name='$search' or father_name='$search' or cnic='$search' or dob='$search' ";
    $result= mysqli_query($link, $query);
    if(mysqli_num_rows($result)){
        while($row= mysqli_fetch_array($result)){
            ?>
        <tr>
        <td><?php echo $row['name'];?></td>
        <td><?php echo $row['father_name'];?></td>
        <td><?php echo $row['head'];?></td>
        <td><?php echo $row['details'];?></td>
        <td><a target="_blank" href="<?php echo $row['picture'];?>" class="btn btn-info">View Image</a></td>
        <td><?php echo $row['status'];?></td>
        </tr>
        <?php
        }
    }else{
        alert("No Record Found");
    }
}
?>
        
        

<?php
require_once 'footer.php';
?>